"use strict";
document.querySelectorAll('.task-workflow').forEach(function (flow) {
 const checks = Array.from(flow.querySelectorAll('.task-check'));
 const status = flow.querySelector('[data-workflow-status]');
 checks.forEach(function (button) {
  button.addEventListener('click', function () {
   button.setAttribute('aria-checked', button.getAttribute('aria-checked') === 'true' ? 'false' : 'true');
   status.textContent = checks.every(function (item) { return item.getAttribute('aria-checked') === 'true'; }) ? status.dataset.ready : status.dataset.pending;
  });
 });
});
